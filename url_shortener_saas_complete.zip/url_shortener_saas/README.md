# URL Shortener SaaS - Flask Application

A complete URL shortening service built with Flask, featuring user authentication, analytics, admin panel, and REST API.

## Features

### Core Features
- ✅ **User Authentication**: Register, login, and secure session management
- ✅ **URL Shortening**: Convert long URLs into short, memorable links
- ✅ **Custom Short Codes**: Users can create custom short codes or use auto-generated ones
- ✅ **Click Analytics**: Track click counts and detailed analytics per URL
- ✅ **User Dashboard**: Manage all created URLs with statistics
- ✅ **URL Expiration**: Set expiration dates for URLs
- ✅ **Active/Inactive Toggle**: Enable/disable URLs without deleting

### Advanced Features
- ✅ **Admin Panel**: Comprehensive admin interface for user and URL management
- ✅ **REST API**: Full API for programmatic access
- ✅ **Security**: Password hashing with bcrypt, CSRF protection
- ✅ **Responsive Design**: Mobile-friendly Bootstrap interface
- ✅ **Database Support**: SQLite (default), MySQL, PostgreSQL
- ✅ **Click Logging**: Detailed click tracking with user agent and IP
- ✅ **Error Handling**: Custom 404, 403, 500 error pages

## Technology Stack

- **Backend**: Flask 2.3.3, Python 3.7+
- **Database**: SQLAlchemy ORM (SQLite/MySQL/PostgreSQL)
- **Authentication**: Flask-Login with bcrypt password hashing
- **Frontend**: Bootstrap 5, Font Awesome, vanilla JavaScript
- **Security**: CSRF protection, secure password hashing
- **API**: RESTful JSON API endpoints

## Quick Start

### 1. Installation

```bash
# Clone or extract the project
cd url_shortener_saas

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configuration

Create a `.env` file in the root directory:

```bash
# .env file
FLASK_APP=run.py
FLASK_ENV=development
SECRET_KEY=your-secret-key-here-change-this-in-production
DATABASE_URL=sqlite:///url_shortener.db
```

### 3. Run the Application

```bash
# Run the application
python run.py
```

The application will be available at `http://localhost:5000`

### 4. Default Admin Account

The application creates a default admin account:
- **Email**: admin@urlshortener.com
- **Password**: admin123

**⚠️ IMPORTANT**: Change this password immediately in production!

## Database Configuration

### SQLite (Default)
No additional configuration needed. Database file will be created automatically.

### PostgreSQL
```bash
# Install PostgreSQL driver
pip install psycopg2-binary

# Set DATABASE_URL in .env
DATABASE_URL=postgresql://username:password@localhost:5432/url_shortener
```

### MySQL
```bash
# Install MySQL driver
pip install PyMySQL

# Set DATABASE_URL in .env
DATABASE_URL=mysql+pymysql://username:password@localhost:3306/url_shortener
```

## API Documentation

### Authentication
All API endpoints require authentication. Include user credentials in the request.

### Endpoints

#### 1. Shorten URL
```http
POST /api/shorten
Content-Type: application/json

{
    "url": "https://example.com/very/long/url",
    "custom_code": "my-link",  // optional
    "expires_in_days": 30      // optional
}
```

**Response:**
```json
{
    "success": true,
    "short_code": "abc123",
    "short_url": "http://localhost:5000/abc123",
    "original_url": "https://example.com/very/long/url",
    "expires_at": "2025-10-21T12:00:00",
    "created_at": "2025-09-21T12:00:00"
}
```

#### 2. Get User's URLs
```http
GET /api/urls?page=1&per_page=10
```

**Response:**
```json
{
    "urls": [...],
    "pagination": {
        "page": 1,
        "pages": 5,
        "per_page": 10,
        "total": 50,
        "has_next": true,
        "has_prev": false
    }
}
```

#### 3. Get URL Information
```http
GET /api/url/{short_code}
```

**Response:**
```json
{
    "short_code": "abc123",
    "short_url": "http://localhost:5000/abc123",
    "original_url": "https://example.com",
    "clicks": 42,
    "is_active": true,
    "created_at": "2025-09-21T12:00:00",
    "expires_at": null,
    "is_expired": false
}
```

## Project Structure

```
url_shortener_saas/
├── run.py                 # Application entry point
├── config.py              # Configuration settings
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── app/
│   ├── __init__.py       # Flask app factory
│   ├── models.py         # Database models
│   ├── routes.py         # Application routes
│   ├── utils.py          # Utility functions
│   ├── templates/        # Jinja2 templates
│   │   ├── base.html     # Base template
│   │   ├── index.html    # Homepage
│   │   ├── login.html    # Login page
│   │   ├── register.html # Registration page
│   │   ├── dashboard.html# User dashboard
│   │   ├── admin.html    # Admin panel
│   │   ├── analytics.html# URL analytics
│   │   ├── 404.html      # Not found page
│   │   ├── 403.html      # Forbidden page
│   │   └── 500.html      # Server error page
│   └── static/           # Static files
│       ├── css/
│       │   └── style.css # Custom styles
│       └── js/
│           └── main.js   # Custom JavaScript
```

## Security Considerations

### For Production Deployment:

1. **Change Secret Key**: Generate a strong secret key
2. **Change Admin Password**: Update default admin credentials
3. **Use HTTPS**: Enable SSL/TLS encryption
4. **Database Security**: Use strong database passwords
5. **Environment Variables**: Store sensitive data in environment variables
6. **Rate Limiting**: Implement rate limiting for API endpoints
7. **Input Validation**: All user inputs are validated and sanitized

### Security Features Implemented:
- Password hashing with bcrypt
- CSRF protection on forms
- SQL injection prevention with SQLAlchemy ORM
- XSS prevention with Jinja2 auto-escaping
- Secure session management
- Input validation and sanitization

## Docker Deployment (Optional)

Create a `Dockerfile`:

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5000

CMD ["python", "run.py"]
```

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  web:
    build: .
    ports:
      - "5000:5000"
    environment:
      - FLASK_ENV=production
      - SECRET_KEY=your-production-secret-key
      - DATABASE_URL=postgresql://user:password@db:5432/url_shortener
    depends_on:
      - db

  db:
    image: postgres:13
    environment:
      - POSTGRES_DB=url_shortener
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

## Development

### Adding New Features

1. **Database Changes**: Update `models.py` and create migrations
2. **Routes**: Add new routes in `routes.py`
3. **Templates**: Create HTML templates in `templates/`
4. **Styles**: Add CSS to `static/css/style.css`
5. **JavaScript**: Add functionality to `static/js/main.js`

### Testing

```bash
# Run basic tests
python -c "from app import create_app; app = create_app(); print('App created successfully')"
```

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check DATABASE_URL in .env file
   - Ensure database server is running
   - Verify credentials and database exists

2. **Import Errors**
   - Ensure virtual environment is activated
   - Run `pip install -r requirements.txt`

3. **Permission Errors**
   - Check file permissions
   - Ensure database directory is writable

4. **Port Already in Use**
   - Change port in run.py: `app.run(port=5001)`
   - Or kill process using port 5000

### Debug Mode

Enable debug mode for development:

```python
# In run.py
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Support

For issues and questions:
1. Check this README for common solutions
2. Review error logs in the console
3. Ensure all dependencies are installed correctly

## Production Deployment Checklist

- [ ] Set strong SECRET_KEY
- [ ] Change default admin password
- [ ] Configure production database
- [ ] Enable HTTPS
- [ ] Set up proper logging
- [ ] Configure backup strategy
- [ ] Implement monitoring
- [ ] Set up rate limiting
- [ ] Configure firewall rules
- [ ] Set up domain and DNS

---

**Built with ❤️ using Flask and Bootstrap**

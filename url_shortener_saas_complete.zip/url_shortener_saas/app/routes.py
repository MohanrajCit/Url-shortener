"""
Main Routes for URL Shortener SaaS
"""
from datetime import datetime, timedelta
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, abort, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.urls import url_parse
from sqlalchemy import desc, func
from app import db
from app.models import User, URL, ClickLog
from app.utils import (
    create_unique_short_code, validate_url, normalize_url, 
    is_valid_custom_code, get_domain_from_url, format_click_count
)

# Create blueprint
main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    """Home page"""
    # Get some statistics for homepage
    stats = {
        'total_urls': URL.query.count(),
        'total_clicks': db.session.query(func.sum(URL.clicks)).scalar() or 0,
        'total_users': User.query.count()
    }
    return render_template('index.html', stats=stats)

@main_bp.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        # Validation
        errors = []

        if len(username) < 3 or len(username) > 80:
            errors.append('Username must be between 3 and 80 characters')

        if User.query.filter_by(username=username).first():
            errors.append('Username already exists')

        if User.query.filter_by(email=email).first():
            errors.append('Email already registered')

        if len(password) < 6:
            errors.append('Password must be at least 6 characters')

        if password != confirm_password:
            errors.append('Passwords do not match')

        if not '@' in email or len(email) < 5:
            errors.append('Invalid email address')

        if errors:
            for error in errors:
                flash(error, 'error')
            return render_template('register.html')

        # Create new user
        try:
            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()

            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('main.login'))
        except Exception as e:
            db.session.rollback()
            flash('Registration failed. Please try again.', 'error')

    return render_template('register.html')

@main_bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))

    if request.method == 'POST':
        username_or_email = request.form.get('username_or_email', '').strip()
        password = request.form.get('password', '')
        remember_me = request.form.get('remember_me') is not None

        # Find user by username or email
        user = User.query.filter(
            (User.username == username_or_email) | 
            (User.email == username_or_email.lower())
        ).first()

        if user and user.check_password(password) and user.is_active:
            login_user(user, remember=remember_me)

            # Redirect to next page or dashboard
            next_page = request.args.get('next')
            if not next_page or url_parse(next_page).netloc != '':
                next_page = url_for('main.dashboard')

            flash(f'Welcome back, {user.username}!', 'success')
            return redirect(next_page)
        else:
            flash('Invalid username/email or password', 'error')

    return render_template('login.html')

@main_bp.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('main.index'))


@main_bp.route('/dashboard')
@login_required
def dashboard():
    """User dashboard"""
    page = request.args.get('page', 1, type=int)
    per_page = 10  # URLs per page

    # Get user's URLs with pagination
    urls = current_user.urls.order_by(desc(URL.created_at)).paginate(
        page=page, per_page=per_page, error_out=False
    )

    # Calculate user statistics
    stats = {
        'total_urls': current_user.get_url_count(),
        'total_clicks': current_user.get_total_clicks(),
        'active_urls': current_user.urls.filter_by(is_active=True).count()
    }

    return render_template('dashboard.html', urls=urls, stats=stats)

@main_bp.route('/shorten', methods=['POST'])
@login_required
def shorten_url():
    """Shorten a URL"""
    original_url = request.form.get('url', '').strip()
    custom_code = request.form.get('custom_code', '').strip()
    expires_in_days = request.form.get('expires_in_days', type=int)

    # Validate URL
    if not original_url:
        flash('Please enter a URL', 'error')
        return redirect(url_for('main.dashboard'))

    if not validate_url(original_url):
        flash('Please enter a valid URL', 'error')
        return redirect(url_for('main.dashboard'))

    # Normalize URL
    original_url = normalize_url(original_url)

    try:
        # Generate or validate short code
        if custom_code:
            if not is_valid_custom_code(custom_code):
                flash('Custom code is invalid or already taken. Use 3-20 characters (letters, numbers, hyphens only).', 'error')
                return redirect(url_for('main.dashboard'))
            short_code = custom_code
            is_custom = True
        else:
            short_code = create_unique_short_code()
            is_custom = False

        # Calculate expiry date
        expires_at = None
        if expires_in_days and expires_in_days > 0:
            expires_at = datetime.utcnow() + timedelta(days=expires_in_days)

        # Create URL record
        url_record = URL(
            user_id=current_user.id,
            original_url=original_url,
            short_code=short_code,
            custom_code=is_custom,
            expires_at=expires_at
        )

        db.session.add(url_record)
        db.session.commit()

        flash(f'URL shortened successfully! Short code: {short_code}', 'success')

    except Exception as e:
        db.session.rollback()
        flash('Error creating short URL. Please try again.', 'error')

    return redirect(url_for('main.dashboard'))

@main_bp.route('/<short_code>')
def redirect_url(short_code):
    """Redirect to original URL"""
    url_record = URL.query.filter_by(short_code=short_code).first()

    if not url_record:
        abort(404)

    if not url_record.is_active:
        flash('This link has been deactivated.', 'error')
        return redirect(url_for('main.index'))

    if url_record.is_expired():
        flash('This link has expired.', 'error')
        return redirect(url_for('main.index'))

    # Log the click
    try:
        url_record.increment_clicks(
            user_agent=request.headers.get('User-Agent'),
            ip_address=request.remote_addr
        )
    except:
        # If logging fails, still redirect but increment simple counter
        url_record.clicks += 1
        db.session.commit()

    return redirect(url_record.original_url)

@main_bp.route('/url/<int:url_id>/analytics')
@login_required
def url_analytics(url_id):
    """Show detailed analytics for a URL"""
    url_record = URL.query.get_or_404(url_id)

    # Check if user owns this URL or is admin
    if url_record.user_id != current_user.id and not current_user.is_admin:
        abort(403)

    # Get click data for last 30 days
    click_data = url_record.get_clicks_by_date(30)

    return render_template('analytics.html', url=url_record, click_data=click_data)

@main_bp.route('/url/<int:url_id>/toggle', methods=['POST'])
@login_required
def toggle_url_status(url_id):
    """Toggle URL active/inactive status"""
    url_record = URL.query.get_or_404(url_id)

    if url_record.user_id != current_user.id and not current_user.is_admin:
        abort(403)

    url_record.is_active = not url_record.is_active
    db.session.commit()

    status = 'activated' if url_record.is_active else 'deactivated'
    flash(f'URL {status} successfully.', 'success')

    return redirect(url_for('main.dashboard'))

@main_bp.route('/url/<int:url_id>/delete', methods=['POST'])
@login_required
def delete_url(url_id):
    """Delete a URL"""
    url_record = URL.query.get_or_404(url_id)

    if url_record.user_id != current_user.id and not current_user.is_admin:
        abort(403)

    try:
        db.session.delete(url_record)
        db.session.commit()
        flash('URL deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error deleting URL.', 'error')

    return redirect(url_for('main.dashboard'))


# Admin Routes
@main_bp.route('/admin')
@login_required
def admin_panel():
    """Admin panel - only accessible by admin users"""
    if not current_user.is_admin:
        abort(403)

    # Get system statistics
    stats = {
        'total_users': User.query.count(),
        'active_users': User.query.filter_by(is_active=True).count(),
        'total_urls': URL.query.count(),
        'active_urls': URL.query.filter_by(is_active=True).count(),
        'total_clicks': db.session.query(func.sum(URL.clicks)).scalar() or 0,
        'clicks_today': db.session.query(func.count(ClickLog.id)).filter(
            func.date(ClickLog.clicked_at) == datetime.utcnow().date()
        ).scalar() or 0
    }

    # Get recent users and URLs
    recent_users = User.query.order_by(desc(User.created_at)).limit(10).all()
    recent_urls = URL.query.order_by(desc(URL.created_at)).limit(10).all()

    return render_template('admin.html', stats=stats, recent_users=recent_users, recent_urls=recent_urls)

@main_bp.route('/admin/users')
@login_required
def admin_users():
    """Admin user management"""
    if not current_user.is_admin:
        abort(403)

    page = request.args.get('page', 1, type=int)
    users = User.query.order_by(desc(User.created_at)).paginate(
        page=page, per_page=20, error_out=False
    )

    return render_template('admin_users.html', users=users)

@main_bp.route('/admin/user/<int:user_id>/toggle', methods=['POST'])
@login_required
def admin_toggle_user(user_id):
    """Toggle user active status"""
    if not current_user.is_admin:
        abort(403)

    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash('Cannot deactivate your own account.', 'error')
    else:
        user.is_active = not user.is_active
        db.session.commit()
        status = 'activated' if user.is_active else 'deactivated'
        flash(f'User {user.username} {status}.', 'success')

    return redirect(url_for('main.admin_users'))

# REST API Routes
@main_bp.route('/api/shorten', methods=['POST'])
@login_required
def api_shorten_url():
    """REST API endpoint to shorten URL"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        original_url = data.get('url', '').strip()
        custom_code = data.get('custom_code', '').strip()
        expires_in_days = data.get('expires_in_days')

        # Validate URL
        if not original_url:
            return jsonify({'error': 'URL is required'}), 400

        if not validate_url(original_url):
            return jsonify({'error': 'Invalid URL'}), 400

        original_url = normalize_url(original_url)

        # Generate or validate short code
        if custom_code:
            if not is_valid_custom_code(custom_code):
                return jsonify({'error': 'Custom code is invalid or already taken'}), 400
            short_code = custom_code
            is_custom = True
        else:
            short_code = create_unique_short_code()
            is_custom = False

        # Calculate expiry
        expires_at = None
        if expires_in_days and expires_in_days > 0:
            expires_at = datetime.utcnow() + timedelta(days=expires_in_days)

        # Create URL record
        url_record = URL(
            user_id=current_user.id,
            original_url=original_url,
            short_code=short_code,
            custom_code=is_custom,
            expires_at=expires_at
        )

        db.session.add(url_record)
        db.session.commit()

        return jsonify({
            'success': True,
            'short_code': short_code,
            'short_url': url_for('main.redirect_url', short_code=short_code, _external=True),
            'original_url': original_url,
            'expires_at': expires_at.isoformat() if expires_at else None,
            'created_at': url_record.created_at.isoformat()
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

@main_bp.route('/api/urls')
@login_required
def api_get_urls():
    """REST API endpoint to get user's URLs"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 10, type=int), 100)

        urls = current_user.urls.order_by(desc(URL.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )

        return jsonify({
            'urls': [{
                'id': url.id,
                'short_code': url.short_code,
                'short_url': url_for('main.redirect_url', short_code=url.short_code, _external=True),
                'original_url': url.original_url,
                'clicks': url.clicks,
                'is_active': url.is_active,
                'created_at': url.created_at.isoformat(),
                'expires_at': url.expires_at.isoformat() if url.expires_at else None
            } for url in urls.items],
            'pagination': {
                'page': urls.page,
                'pages': urls.pages,
                'per_page': urls.per_page,
                'total': urls.total,
                'has_next': urls.has_next,
                'has_prev': urls.has_prev
            }
        })

    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@main_bp.route('/api/url/<short_code>')
def api_get_url_info(short_code):
    """REST API endpoint to get URL information"""
    url_record = URL.query.filter_by(short_code=short_code).first()

    if not url_record:
        return jsonify({'error': 'URL not found'}), 404

    return jsonify({
        'short_code': url_record.short_code,
        'short_url': url_for('main.redirect_url', short_code=short_code, _external=True),
        'original_url': url_record.original_url,
        'clicks': url_record.clicks,
        'is_active': url_record.is_active,
        'created_at': url_record.created_at.isoformat(),
        'expires_at': url_record.expires_at.isoformat() if url_record.expires_at else None,
        'is_expired': url_record.is_expired()
    })

# Error handlers
@main_bp.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@main_bp.errorhandler(403)
def forbidden_error(error):
    return render_template('403.html'), 403

@main_bp.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

"""
Database Models for URL Shortener
"""
from datetime import datetime, timedelta
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db

class User(UserMixin, db.Model):
    """User model for authentication and URL management"""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    # Relationship with URLs
    urls = db.relationship('URL', backref='owner', lazy='dynamic', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<User {self.username}>'

    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Check if provided password matches hash"""
        return check_password_hash(self.password_hash, password)

    def get_url_count(self):
        """Get total number of URLs created by user"""
        return self.urls.count()

    def get_total_clicks(self):
        """Get total clicks across all user's URLs"""
        return sum(url.clicks for url in self.urls)

class URL(db.Model):
    """URL model for storing shortened URLs"""
    __tablename__ = 'urls'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    original_url = db.Column(db.Text, nullable=False)
    short_code = db.Column(db.String(20), unique=True, nullable=False, index=True)
    custom_code = db.Column(db.Boolean, default=False)  # Track if user provided custom code
    clicks = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)

    # Analytics - Store click timestamps for detailed analytics
    click_logs = db.relationship('ClickLog', backref='url', lazy='dynamic', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<URL {self.short_code}>'

    def is_expired(self):
        """Check if URL has expired"""
        if self.expires_at:
            return datetime.utcnow() > self.expires_at
        return False

    def increment_clicks(self, user_agent=None, ip_address=None):
        """Increment click count and log the click"""
        self.clicks += 1

        # Create click log entry for analytics
        click_log = ClickLog(
            url_id=self.id,
            clicked_at=datetime.utcnow(),
            user_agent=user_agent,
            ip_address=ip_address
        )
        db.session.add(click_log)
        db.session.commit()

    def get_clicks_by_date(self, days=30):
        """Get click counts grouped by date for the last N days"""
        from sqlalchemy import func

        start_date = datetime.utcnow() - timedelta(days=days)

        results = db.session.query(
            func.date(ClickLog.clicked_at).label('date'),
            func.count(ClickLog.id).label('count')
        ).filter(
            ClickLog.url_id == self.id,
            ClickLog.clicked_at >= start_date
        ).group_by(
            func.date(ClickLog.clicked_at)
        ).order_by('date').all()

        return results

class ClickLog(db.Model):
    """Model to track individual clicks for analytics"""
    __tablename__ = 'click_logs'

    id = db.Column(db.Integer, primary_key=True)
    url_id = db.Column(db.Integer, db.ForeignKey('urls.id'), nullable=False)
    clicked_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    user_agent = db.Column(db.String(500))
    ip_address = db.Column(db.String(45))  # Support IPv6

    def __repr__(self):
        return f'<ClickLog {self.url_id} at {self.clicked_at}>'

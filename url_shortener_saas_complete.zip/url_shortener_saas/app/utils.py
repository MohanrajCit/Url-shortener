"""
Utility functions for URL Shortener
"""
import random
import string
import validators
from app.models import URL

def generate_short_code(length=6):
    """
    Generate a random short code for URLs
    Args:
        length (int): Length of the short code (default 6)
    Returns:
        str: Random alphanumeric string
    """
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def create_unique_short_code(length=6, max_attempts=100):
    """
    Create a unique short code that doesn't exist in database
    Args:
        length (int): Length of the short code
        max_attempts (int): Maximum attempts to generate unique code
    Returns:
        str: Unique short code
    Raises:
        ValueError: If unable to generate unique code after max_attempts
    """
    for attempt in range(max_attempts):
        short_code = generate_short_code(length)

        # Check if code already exists
        existing_url = URL.query.filter_by(short_code=short_code).first()
        if not existing_url:
            return short_code

    # If we can't generate unique code, increase length and try once more
    return create_unique_short_code(length + 1, max_attempts=10)

def validate_url(url):
    """
    Validate if the provided string is a valid URL
    Args:
        url (str): URL to validate
    Returns:
        bool: True if valid URL, False otherwise
    """
    # Add http:// if no protocol specified
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url

    return validators.url(url)

def normalize_url(url):
    """
    Normalize URL by adding protocol if missing
    Args:
        url (str): URL to normalize
    Returns:
        str: Normalized URL
    """
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url
    return url

def is_valid_custom_code(code):
    """
    Validate custom short code provided by user
    Args:
        code (str): Custom code to validate
    Returns:
        bool: True if valid custom code
    """
    # Check length (3-20 characters)
    if len(code) < 3 or len(code) > 20:
        return False

    # Check if contains only alphanumeric characters and hyphens
    allowed_chars = string.ascii_letters + string.digits + '-'
    if not all(char in allowed_chars for char in code):
        return False

    # Check if code is already taken
    existing_url = URL.query.filter_by(short_code=code).first()
    return existing_url is None

def get_domain_from_url(url):
    """
    Extract domain from URL for display purposes
    Args:
        url (str): Full URL
    Returns:
        str: Domain name
    """
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return parsed.netloc
    except:
        return url

def format_click_count(count):
    """
    Format click count for display (e.g., 1.2K, 1.5M)
    Args:
        count (int): Number of clicks
    Returns:
        str: Formatted count
    """
    if count < 1000:
        return str(count)
    elif count < 1000000:
        return f"{count/1000:.1f}K"
    else:
        return f"{count/1000000:.1f}M"

def is_safe_url(target):
    """
    Check if a redirect URL is safe (same domain)
    Args:
        target (str): Target URL to check
    Returns:
        bool: True if safe to redirect
    """
    from urllib.parse import urlparse, urljoin
    from flask import request

    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return test_url.scheme in ('http', 'https') and ref_url.netloc == test_url.netloc

// Custom JavaScript for URL Shortener SaaS

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Form validation enhancement
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
});

// Copy to clipboard function
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function() {
            showCopySuccess();
        }).catch(function(err) {
            console.error('Could not copy text: ', err);
            fallbackCopyTextToClipboard(text);
        });
    } else {
        fallbackCopyTextToClipboard(text);
    }
}

// Fallback copy function for older browsers
function fallbackCopyTextToClipboard(text) {
    var textArea = document.createElement("textarea");
    textArea.value = text;

    // Avoid scrolling to bottom
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.position = "fixed";

    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
        var successful = document.execCommand('copy');
        if (successful) {
            showCopySuccess();
        }
    } catch (err) {
        console.error('Fallback: Oops, unable to copy', err);
    }

    document.body.removeChild(textArea);
}

// Show copy success notification
function showCopySuccess() {
    // Create toast notification
    var toastHtml = `
        <div class="position-fixed top-0 end-0 p-3" style="z-index: 1060">
            <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <i class="fas fa-check-circle text-success me-2"></i>
                    <strong class="me-auto">Success</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    URL copied to clipboard!
                </div>
            </div>
        </div>
    `;

    // Insert toast into page
    var toastContainer = document.createElement('div');
    toastContainer.innerHTML = toastHtml;
    document.body.appendChild(toastContainer);

    // Auto remove toast after 3 seconds
    setTimeout(function() {
        document.body.removeChild(toastContainer);
    }, 3000);
}

// URL validation
function validateUrl(url) {
    var pattern = new RegExp('^(https?:\/\/)?' + // protocol
        '((([a-z\d]([a-z\d-]*[a-z\d])*)\.)+[a-z]{2,}|' + // domain name
        '((\d{1,3}\.){3}\d{1,3}))' + // OR ip (v4) address
        '(\:\d+)?(\/[-a-z\d%_.~+]*)*' + // port and path
        '(\?[;&a-z\d%_.~+=-]*)?' + // query string
        '(\#[-a-z\d_]*)?$', 'i'); // fragment locator
    return !!pattern.test(url);
}

// Custom code validation
function validateCustomCode(code) {
    if (code.length < 3 || code.length > 20) {
        return false;
    }
    var pattern = /^[a-zA-Z0-9-]+$/;
    return pattern.test(code);
}

// Real-time form validation
document.addEventListener('DOMContentLoaded', function() {
    var urlInput = document.getElementById('url');
    var customCodeInput = document.getElementById('custom_code');

    if (urlInput) {
        urlInput.addEventListener('blur', function() {
            var url = this.value.trim();
            if (url && !validateUrl(url)) {
                this.classList.add('is-invalid');
                showValidationError(this, 'Please enter a valid URL');
            } else {
                this.classList.remove('is-invalid');
                hideValidationError(this);
            }
        });
    }

    if (customCodeInput) {
        customCodeInput.addEventListener('blur', function() {
            var code = this.value.trim();
            if (code && !validateCustomCode(code)) {
                this.classList.add('is-invalid');
                showValidationError(this, 'Code must be 3-20 characters (letters, numbers, hyphens only)');
            } else {
                this.classList.remove('is-invalid');
                hideValidationError(this);
            }
        });
    }
});

function showValidationError(element, message) {
    var feedback = element.parentNode.querySelector('.invalid-feedback');
    if (!feedback) {
        feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        element.parentNode.appendChild(feedback);
    }
    feedback.textContent = message;
}

function hideValidationError(element) {
    var feedback = element.parentNode.querySelector('.invalid-feedback');
    if (feedback) {
        feedback.remove();
    }
}

// Analytics chart (simple implementation)
function drawSimpleChart(data, elementId) {
    var canvas = document.getElementById(elementId);
    if (!canvas) return;

    var ctx = canvas.getContext('2d');
    var width = canvas.width;
    var height = canvas.height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    if (data.length === 0) return;

    // Find max value for scaling
    var maxValue = Math.max(...data.map(d => d.count));

    // Draw bars
    var barWidth = width / data.length;
    data.forEach(function(item, index) {
        var barHeight = (item.count / maxValue) * (height - 20);
        var x = index * barWidth;
        var y = height - barHeight - 10;

        ctx.fillStyle = '#007bff';
        ctx.fillRect(x + 5, y, barWidth - 10, barHeight);

        // Draw value on top
        ctx.fillStyle = '#333';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(item.count, x + barWidth/2, y - 5);
    });
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Add loading state to forms
document.addEventListener('DOMContentLoaded', function() {
    var forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function() {
            var submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span>Processing...';
            }
        });
    });
});

// Auto-refresh analytics data (every 30 seconds)
function autoRefreshAnalytics() {
    if (window.location.pathname.includes('/analytics')) {
        setTimeout(function() {
            window.location.reload();
        }, 30000);
    }
}

// Initialize auto-refresh
document.addEventListener('DOMContentLoaded', autoRefreshAnalytics);

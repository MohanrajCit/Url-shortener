#!/usr/bin/env python3
"""
URL Shortener SaaS - Main Application Entry Point
Author: AI Assistant
Date: 2025
"""

import os
from app import create_app, db
from app.models import User, URL

# Create Flask application instance
app = create_app(os.getenv('FLASK_CONFIG') or 'default')

@app.shell_context_processor
def make_shell_context():
    """Make database models available in Flask shell"""
    return {'db': db, 'User': User, 'URL': URL}

@app.before_first_request
def create_tables():
    """Create database tables if they don't exist"""
    db.create_all()

if __name__ == '__main__':
    # Create database tables
    with app.app_context():
        db.create_all()

        # Create admin user if it doesn't exist
        admin_user = User.query.filter_by(email='admin@urlshortener.com').first()
        if not admin_user:
            admin_user = User(
                username='admin',
                email='admin@urlshortener.com',
                is_admin=True
            )
            admin_user.set_password('admin123')
            db.session.add(admin_user)
            db.session.commit()
            print("Created admin user: admin@urlshortener.com / admin123")

    # Run the application
    app.run(host='0.0.0.0', port=5000, debug=True)
